 #!/usr/bin/env python
 # license removed for brevity
import rospy
from std_msgs.msg import Float64
def talker():
	pub = rospy.Publisher('/scara_robot/joint2_position_controller/command', Float64, queue_size=10)
	pub1 = rospy.Publisher('/scara_robot/joint1_position_controller/command', Float64, queue_size=10)
	rospy.init_node('talker', anonymous=True)
	rate = rospy.Rate(10) # 10hz
	while not rospy.is_shutdown():
	   hello_str = 1.0
	   hello_str1 = 0.5
	   rospy.loginfo(hello_str)
	   pub.publish(hello_str)
	   rospy.loginfo(hello_str1)
	   pub1.publish(hello_str1)
	   rate.sleep()

if __name__ == '__main__':
	try:
	   talker()
	except rospy.ROSInterruptException:
	   pass

