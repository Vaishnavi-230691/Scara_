
"use strict";

let jacob = require('./jacob.js')
let inv = require('./inv.js')
let inv_jacob = require('./inv_jacob.js')

module.exports = {
  jacob: jacob,
  inv: inv,
  inv_jacob: inv_jacob,
};
